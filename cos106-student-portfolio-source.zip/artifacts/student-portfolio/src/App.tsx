import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDownRight, ArrowRight, ArrowUpRight, BookOpen, Check, Menu, Plus, Trash2, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const navItems = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/projects', label: 'Projects' },
  { href: '/planner', label: 'Study planner' },
  { href: '/contact', label: 'Contact' },
];
const studentProfile = {
  fullName: 'KOKORIMAM ZAKKA',
  email: 'kokorimam.zakka@miva.edu.ng',
  department: 'CYBERSECURITY',
  matriculationNumber: '2024/C/CYB/0926',
  institution: 'MIVA Open University',
};

function Header() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  return <header className="page-wrap topbar">
    <Link href="/" className="brand" data-testid="link-brand"><span className="brand-mark">KZ</span><span className="brand-name">{studentProfile.fullName}</span></Link>
    <button className="menu-toggle" aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} data-testid="button-mobile-menu" onClick={() => setOpen(!open)}>{open ? <X size={22} /> : <Menu size={22} />}</button>
    <nav className={`nav-links ${open ? 'open' : ''}`} aria-label="Main navigation">
      {navItems.map(item => <Link key={item.href} href={item.href} className={`nav-link ${location === item.href ? 'active' : ''}`} onClick={() => setOpen(false)} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>{item.label}</Link>)}
    </nav>
  </header>;
}

function Footer() {
  return <footer className="page-wrap footer"><span>Designed as a COS 106 term project · {studentProfile.fullName}</span><span>{studentProfile.department} · 2026</span></footer>;
}

function Layout({ children }: { children: ReactNode }) {
  return <div className="site-shell"><Header /><main className="page-content">{children}</main><Footer /></div>;
}

function Home() {
  return <Layout>
    <div className="page-wrap">
      <section className="hero">
        <div>
          <span className="eyebrow">COS 106 · Introduction to Web Technologies</span>
          <p className="student-name" data-testid="text-student-name">{studentProfile.fullName}<span>{studentProfile.department}</span></p>
          <h1 className="serif">Curious by nature.<br /><em>Building for people.</em></h1>
          <p className="hero-copy">A student of cybersecurity at MIVA Open University, building knowledge in system protection, networks, data security, and the technologies behind the web.</p>
          <div className="hero-actions">
            <Link href="/projects" className="button button-primary" data-testid="button-explore-projects">Explore my work <ArrowRight size={16} /></Link>
            <Link href="/about" className="button button-outline" data-testid="button-about-me">A little about me <ArrowDownRight size={16} /></Link>
          </div>
        </div>
        <div className="hero-art">
          <div className="orbit" /><span className="orbit-label">COS 106 · 2026</span>
          <div className="portrait-card"><img className="portrait-image" src="/student-portfolio/student-portrait.jpg" alt="Portrait of Kokorimam Zakka" /><div className="portrait-note">KOKORIMAM<br />CYBERSECURITY</div></div>
        </div>
      </section>
      <section className="section">
        <div className="section-heading"><div><span className="eyebrow">A small introduction</span><h2 className="serif">The work is the point.</h2></div><p>A student portfolio with an academic snapshot, responsive web work, and practical tools for planning study and communicating clearly.</p></div>
        <div className="highlight-grid">
          <article className="feature-card dark-card"><span className="eyebrow">01 / What I’m studying</span><h3>Web technologies, from the ground up.</h3><p>Learning how structure, style, and interaction come together to make useful and thoughtful experiences on the web.</p><div className="pill-row"><span className="pill">HTML & CSS</span><span className="pill">JavaScript</span><span className="pill">Design systems</span></div></article>
          <article className="feature-card"><span className="eyebrow">02 / What’s next</span><h3>Make a little. Learn a lot.</h3><p>Use the academic planner to keep coursework moving, then explore the projects that bring this portfolio together.</p><Link href="/planner" className="project-link" data-testid="link-planner-callout">Open study planner <ArrowUpRight size={15} /></Link></article>
        </div>
      </section>
      <section className="section">
        <div className="section-heading"><div><span className="eyebrow">Featured work</span><h2 className="serif">Small ideas, made tangible.</h2></div><Link href="/projects" className="project-link" data-testid="link-all-projects">All projects <ArrowRight size={15} /></Link></div>
        <div className="highlight-grid">
          <article className="feature-card"><span className="eyebrow">01 · Responsive web design</span><h3>Student portfolio</h3><p>A responsive, multi-page portfolio presenting academic background, skills, career goals, interests, and project work.</p><div className="pill-row"><span className="pill">HTML</span><span className="pill">CSS</span><span className="pill">JavaScript</span></div></article>
          <article className="feature-card"><span className="eyebrow">02 · Study productivity</span><h3>Academic task planner</h3><p>An interactive study list for adding tasks, tracking completion, and keeping academic work organized.</p><Link href="/projects" className="project-link" data-testid="link-project-detail">View all projects <ArrowRight size={15} /></Link></article>
        </div>
      </section>
      <div className="quote-block"><span className="quote-mark">“</span><blockquote>Clear structure. Useful interactions. Safer digital choices.<cite>PORTFOLIO FOCUS · CYBERSECURITY &amp; WEB TECHNOLOGIES</cite></blockquote></div>
    </div>
  </Layout>;
}

function About() {
  const skills = ['HTML5 semantics', 'CSS Grid & Flexbox', 'JavaScript fundamentals', 'Responsive design', 'Accessibility basics', 'Git & version control', 'Cybersecurity fundamentals · learning', 'Digital safety awareness'];
  return <Layout><div className="page-wrap">
    <section className="page-hero"><span className="eyebrow">About the student behind the screen</span><h1 className="serif">A work in progress.<br /><em style={{ color: 'hsl(var(--accent))' }}>In the best way.</em></h1><p>A little context on what I’m studying, what I’m curious about, and where I hope this path might lead.</p></section>
    <div className="about-grid">
      <aside className="profile-note"><span className="eyebrow">Student profile</span><h2>{studentProfile.fullName}</h2><p><strong>Institution:</strong> {studentProfile.institution}<br /><strong>Department:</strong> {studentProfile.department}<br /><strong>Matriculation number:</strong> {studentProfile.matriculationNumber}<br /><strong>Email:</strong> {studentProfile.email}</p><Link href="/contact" className="project-link" data-testid="link-contact-about">Get in touch <ArrowRight size={15} /></Link></aside>
      <div>
        <div className="timeline">
          <article className="timeline-item"><span className="timeline-date">CURRENT · 2026</span><h3>Undergraduate study</h3><p>Studying in the Department of <strong>{studentProfile.department}</strong> at <strong>{studentProfile.institution}</strong>. Current coursework includes COS 106: Introduction to Web Technologies.</p></article>
          <article className="timeline-item"><span className="timeline-date">CAREER GOAL</span><h3>Cybersecurity professional</h3><p>Build a successful career protecting computer systems, networks, and data from cyber threats. Develop strong skills in ethical hacking, network security, digital forensics, and security analysis, and help create safer digital environments.</p></article>
          <article className="timeline-item"><span className="timeline-date">HOBBIES &amp; INTERESTS</span><h3>Technology, learning, and new places</h3><p>Learning about cybersecurity and technology; exploring software and computer systems; watching technology-related content; learning programming; music; and traveling.</p></article>
        </div>
        <section style={{ marginTop: 14 }}><span className="eyebrow">Current learning areas</span><div className="skill-list" style={{ marginTop: 17 }}>{skills.map((skill, index) => <span className="skill-chip" key={skill} data-testid={`skill-${index}`}>{skill}</span>)}</div></section>
        <div className="table-wrap"><table className="course-table"><caption>Academic snapshot</caption><thead><tr><th>Course or area</th><th>Focus</th><th>Status</th></tr></thead><tbody><tr><td>COS 106</td><td>Web technologies</td><td>In progress</td></tr><tr><td>Cybersecurity studies</td><td>Digital security foundations</td><td>Current department</td></tr><tr><td>Student portfolio</td><td>HTML, CSS, JavaScript</td><td>Course project</td></tr></tbody></table></div>
        <div className="audio-card"><span className="eyebrow">A quiet study break</span><small>A short synthesized chime for the multimedia element.</small><audio controls aria-label="Short study break chime"><source src="/student-portfolio/study-chime.wav" type="audio/wav" />Your browser does not support audio playback.</audio></div>
      </div>
    </div>
  </div></Layout>;
}

const projects = [
  { id: 'portfolio', number: '01', title: 'Responsive Student Portfolio Website', type: 'MULTI-PAGE RESPONSIVE WEBSITE', desc: 'A responsive website showcasing academic background, technical skills, career aspirations, interests, and project work. Built with HTML, CSS, and JavaScript.', image: '/student-portfolio/fieldnotes.svg', tone: 'sage', tech: ['HTML', 'CSS', 'JavaScript'], href: '/about', linkLabel: 'View profile details' },
  { id: 'academic-planner', number: '02', title: 'Academic Task Planner', type: 'INTERACTIVE STUDY TOOL', desc: 'An interactive planner that lets students add, complete, and delete academic tasks. The task list is saved in the browser between visits.', image: '/student-portfolio/compass.svg', tone: 'clay', tech: ['JavaScript', 'Local storage', 'Responsive UI'], href: '/planner', linkLabel: 'Open the planner' },
  { id: 'contact-form', number: '03', title: 'Student Contact & Validation Form', type: 'FORM VALIDATION', desc: 'A student contact form that collects user information and validates required fields, email format, and digits-only phone input with JavaScript.', image: '/student-portfolio/focus.svg', tone: 'blue', tech: ['HTML forms', 'JavaScript', 'Validation'], href: '/contact', linkLabel: 'Try the contact form' },
];

function Projects() {
  return <Layout><div className="page-wrap">
    <section className="page-hero"><span className="eyebrow">COS 106 projects · 2026</span><h1 className="serif">Learning by <em style={{ color: 'hsl(var(--accent))' }}>making.</em></h1><p>The work behind my COS 106 portfolio: a responsive personal site, an interactive academic planner, and a JavaScript-validated contact form.</p></section>
    <div className="projects-grid">{projects.map(project => <article className="project-card" key={project.id} data-testid={`card-project-${project.id}`}>
      <div className={`project-image project-image--${project.tone}`}><img src={project.image} alt={`${project.title} project interface preview`} data-testid={`img-project-${project.id}`} /></div>
      <div className="project-info"><span className="eyebrow">{project.number} / {project.type}</span><h2>{project.title}</h2><p>{project.desc}</p><div className="pill-row">{project.tech.map(tech => <span className="pill" key={tech}>{tech}</span>)}</div><div className="project-meta"><span className="eyebrow">COS 106 PROJECT</span><Link className="project-link" href={project.href} data-testid={`link-project-${project.id}`}>{project.linkLabel} <ArrowUpRight size={14} /></Link></div></div>
    </article>)}</div>
  </div></Layout>;
}

type Task = { id: string; title: string; due: string; course: string; done: boolean };
const starterTasks: Task[] = [
  { id: 'welcome-1', title: 'Review semantic HTML notes', due: '', course: 'COS 106', done: false },
  { id: 'welcome-2', title: 'Sketch portfolio wireframe', due: '', course: 'Personal project', done: false },
  { id: 'welcome-3', title: 'Read about CSS Grid', due: '', course: 'COS 106', done: true },
];
function Planner() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState('');
  const [course, setCourse] = useState('COS 106');
  const [due, setDue] = useState('');
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try { const stored = localStorage.getItem('cos106-planner-tasks'); setTasks(stored ? JSON.parse(stored) as Task[] : starterTasks); }
    catch { setTasks(starterTasks); }
    setReady(true);
  }, []);
  useEffect(() => { if (ready) localStorage.setItem('cos106-planner-tasks', JSON.stringify(tasks)); }, [tasks, ready]);
  const completed = useMemo(() => tasks.filter(task => task.done).length, [tasks]);
  function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!title.trim()) return;
    setTasks(current => [{ id: `${Date.now()}`, title: title.trim(), course: course.trim() || 'Personal', due, done: false }, ...current]);
    setTitle('');
  }
  function toggleTask(id: string) { setTasks(current => current.map(task => task.id === id ? { ...task, done: !task.done } : task)); }
  function removeTask(id: string) { setTasks(current => current.filter(task => task.id !== id)); }
  const dateLabel = (date: string) => date ? new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date(`${date}T12:00:00`)) : 'No due date';
  return <Layout><div className="page-wrap">
    <section className="page-hero"><span className="eyebrow">Your little corner of focus</span><h1 className="serif">Make room for <em style={{ color: 'hsl(var(--accent))' }}>the next thing.</em></h1><p>A simple, private study list saved in this browser. Add the work, mark the progress, then get back to it.</p></section>
    <div className="planner-layout">
      <section className="planner-panel"><h2>Add a study task</h2><form className="task-form" onSubmit={addTask}>
        <div><label className="field-label" htmlFor="task-title">Task</label><input id="task-title" className="field" placeholder="What needs your attention?" value={title} onChange={event => setTitle(event.target.value)} required data-testid="input-task-title" /></div>
        <div><label className="field-label" htmlFor="task-course">Course or project</label><input id="task-course" className="field" placeholder="COS 106" value={course} onChange={event => setCourse(event.target.value)} data-testid="input-task-course" /></div>
        <div><label className="field-label" htmlFor="task-due">Due date <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 400 }}>(optional)</span></label><input id="task-due" className="field" type="date" value={due} onChange={event => setDue(event.target.value)} data-testid="input-task-due" /></div>
        <button type="submit" className="button button-primary" data-testid="button-add-task"><Plus size={16} /> Add to my list</button>
      </form></section>
      <section className="planner-panel"><div className="planner-summary"><span>YOUR TASKS</span><span data-testid="text-task-count">{completed} OF {tasks.length} COMPLETE</span></div><div className="progress-track" aria-label={`${tasks.length ? Math.round(completed / tasks.length * 100) : 0}% complete`}><div className="progress-fill" style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div>
        {!ready ? <div className="empty-state" aria-label="Loading tasks"><strong>Gathering your list…</strong><span>Your saved tasks will be here in a moment.</span></div> : tasks.length === 0 ? <div className="empty-state"><BookOpen size={25} /><strong>A little breathing room.</strong><span>Add a task when you’re ready to plan your next study session.</span></div> :
          <div className="task-list">{tasks.map(task => <div className={`task-row ${task.done ? 'done' : ''}`} key={task.id} data-testid={`task-row-${task.id}`}>
            <input type="checkbox" className="task-check" checked={task.done} onChange={() => toggleTask(task.id)} aria-label={`${task.done ? 'Mark incomplete' : 'Mark complete'}: ${task.title}`} data-testid={`checkbox-task-${task.id}`} />
            <div className="task-copy"><strong>{task.title}</strong><small>{task.course} · {dateLabel(task.due)}</small></div>
            {task.done && <Check size={16} color="hsl(var(--accent))" aria-label="Complete" />}
            <button className="icon-button" aria-label={`Delete ${task.title}`} onClick={() => removeTask(task.id)} data-testid={`button-delete-task-${task.id}`}><Trash2 size={16} /></button>
          </div>)}</div>}
      </section>
    </div>
  </div></Layout>;
}

function Contact() {
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  function submitContact(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const name = String(data.get('name') ?? '').trim();
    const email = String(data.get('email') ?? '').trim();
    const phone = String(data.get('phone') ?? '').trim();
    const message = String(data.get('message') ?? '').trim();
    if (!name || !email || !phone || !message) { setFeedback({ type: 'error', text: 'Please complete every field before sending.' }); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setFeedback({ type: 'error', text: 'That email address doesn’t look quite right. Check it and try again.' }); return; }
    if (!/^\d+$/.test(phone)) { setFeedback({ type: 'error', text: 'Enter your phone number using digits only, with no spaces or symbols.' }); return; }
    setFeedback({ type: 'success', text: `Thanks, ${name}. Your message is ready — this demo form does not send data to a server.` });
    form.reset();
  }
  return <Layout><div className="page-wrap">
    <section className="page-hero"><span className="eyebrow">A note is always welcome</span><h1 className="serif">Let’s start a <em style={{ color: 'hsl(var(--accent))' }}>conversation.</em></h1><p>Have a question about a project, a resource to share, or an idea worth exploring? Send a note below.</p></section>
    <div className="contact-grid">
      <aside className="contact-aside"><span className="eyebrow" style={{ color: '#e8b19b' }}>Say hello</span><h2>Good things start with a question.</h2><p>This is a front-end demonstration. Messages are validated in your browser and are not transmitted to a server.</p><div className="contact-detail"><strong>Student</strong><br />{studentProfile.fullName}</div><div className="contact-detail"><strong>University email</strong><br />{studentProfile.email}</div><Link href="/projects" className="project-link" style={{ color: '#f6f0e5', marginTop: 17 }} data-testid="link-contact-projects">Browse project work <ArrowRight size={15} /></Link></aside>
      <form className="contact-form" onSubmit={submitContact} noValidate>
        <div><label className="field-label" htmlFor="contact-name">Your name</label><input id="contact-name" className="field" name="name" autoComplete="name" placeholder="Name" required data-testid="input-contact-name" /></div>
        <div><label className="field-label" htmlFor="contact-email">Email address</label><input id="contact-email" className="field" name="email" type="email" autoComplete="email" placeholder="you@example.edu" required data-testid="input-contact-email" /></div>
        <div><label className="field-label" htmlFor="contact-phone">Phone number · digits only</label><input id="contact-phone" className="field" name="phone" type="tel" inputMode="numeric" placeholder="0123456789" required data-testid="input-contact-phone" /></div>
        <div className="wide"><label className="field-label" htmlFor="contact-message">Your message</label><textarea id="contact-message" className="field" name="message" placeholder="What would you like to talk about?" required data-testid="input-contact-message" /></div>
        {feedback && <div className={`feedback ${feedback.type} wide`} role="status" data-testid={`status-contact-${feedback.type}`}>{feedback.text}</div>}
        <div className="wide"><button className="button button-primary" type="submit" data-testid="button-send-message">Review my message <ArrowRight size={16} /></button></div>
      </form>
    </div>
  </div></Layout>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Home} />
    <Route path="/about" component={About} />
    <Route path="/projects" component={Projects} />
    <Route path="/planner" component={Planner} />
    <Route path="/contact" component={Contact} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;